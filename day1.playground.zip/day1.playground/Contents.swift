import UIKit

//Str variables
var str = "Hello, playground"
str="Goodbye"

//int variables
var age=38
var population=8_000_000

//multi-line string
var str1 = """
This goes
over multiple
lines
"""
//multi-line string without line changes
var str2 = """
This goes \
over multiple \
lines
"""

//doubles and booleans
var pi=3.141
var awesome=true

//string interpolation
var score=85
var str3="Your score was \(score)"
var results="The test results are here: \(str3)"

//constants
let taylor="swift"

//type annotations
let str4="Hello, playground"
let album: String = "Reputation"
let year: Int = 1989
let height: Double = 1.78
let taylorRocks: Bool = true

//arrays
let john="John Lennon"
let paul="Paul McCartney"
let george="George Harrison"
let ringo="Ringo Starr"
let beatles=[john,paul,george,ringo]
beatles[1]

//sets
let colors=Set(["red", "green", "blue"])
let colors2=Set(["red", "green", "blue", "red", "blue"])

//tuples
var name = (first: "Taylor", last: "Swift")
name.0
name.first

//tuples vs sets vs arrays
let address = (house: 555, street: "Taylor Swift Avenue", city: "Nashville")
let set = Set(["aardvark", "astronaut", "azalea"])
let pythons = ["Eric", "Graham", "John", "Michael", "Terry", "Terry"]

//dictionaries
let heights = [
    "Taylor Swift": 1.78,
    "Ed Sheeran": 1.73
]
//returns Taylor Swift's height
heights["Taylor Swift"]

//dictionary default values
let favoriteIceCream = [
    "Paul": "Chocolate",
    "Sophie": "Vanilla"
]
//returns Paul's favorite ice cream
favoriteIceCream["Paul"]
//returns default value of Unknown
favoriteIceCream["Charlotte", default: "Unknown"]

//empty collections
//creates empty dictionary, assigns one value
var teams = [String: String]()
teams["Paul"]="Red"
//creates empty array of ints
var results2 = [Int]()
//create empty sets of strings/ints
var words = Set<String>()
var numbers = Set<Int>()
//another way to create empty dictionary/array
var scores = Dictionary<String, Int>()
var results3 = Array<Int>()

//enums
enum Result {
    case success
    case failure
}
let result4 = Result.failure

//enum associated values
enum Activity {
    case bored
    case running(destination: String)
    case talking(topic: String)
    case singing(volume: Int)
}
//assigns topic of talking to football
let talking = Activity.talking(topic: "football")

//enum raw values
enum Planet: Int{
    //assigns mercury number 1, others shift +1
    case mercury=1
    case venus
    case earth
    case mars
}

//arithmetic operators
let firstScore=12
let secondScore=4
let total=firstScore+secondScore
let difference=firstScore-secondScore
let product=firstScore*secondScore
let divided=firstScore/secondScore
let remainder=13%secondScore

//operator overloading
let meaningOflife=42
let doubleMeaning=42+42
let fakers="Fakers gonna"
let action=fakers+"fake"
let firstHalf=["John","Paul"]
let secondHalf=["George","Ringo"]
let beatles2=firstHalf+secondHalf

//compound assignment operators
var score2=5
score2-=5
var quote = "The rain in Spain falls mainly on the"
quote += "Spaniards"

//comparison operators
let firstScore2 = 6
let secondScore2 = 4
firstScore2==secondScore2
firstScore2 != secondScore2
firstScore<secondScore
firstScore>=secondScore
"Taylor" <  "Swift"

//conditions
let firstCard = 11
let secondCard = 10
if firstCard + secondCard == 2 {
    print("Aces - lucky!")
} else if firstCard + secondCard == 21 {
    print("Blackjack!")
} else {
    print("Regular cards")
}

//combining operators
let age1=12
let age2=21
if age1>18 && age2>18 {
    print("Both are over 18")
}
if age1>18 || age2>18 {
    print("At least one is over 18")
}

//ternary operators
let firstCard2=11
let secondCard2=10
//prints first string if condition is true, second if false
print(firstCard2==secondCard2 ? "Cards are the same" : "Cards are different")

//switch statements
let weather="sunny"
switch weather {
case "rain":
    print("Bring an umbrella")
case "snow":
    print("Wrap up warm")
case "sunny":
    print("Wear sunscreen")
    fallthrough
default:
    print("Have a nice day")
}

//range operators
let score5=85
switch score5 {
case 0..<50:
    print("You failed badly.")
case 50..<85:
    print("You did OK.")
default:
    print("You did great!")
}

//for loops
let count=1...10

for number in count {
    print("Number is \(number)")
}

let albums = ["Red", "1989", "Reputation"]

for album in albums {
    print("\(album) is on Apple Music")
}

print("Players gonna ")
for _ in 1...5 {
    print("play")
}

//while loops
var number = 1

while number <= 20 {
    print(number)
    number+=1
}

print("Ready or not, here I come!")

//repeat loops
var num=1
repeat {
    print(num)
    num+=1
} while number <= 20

print("Ready or not, here I come!")

//exiting loops
var countDown=10
while countDown>=0{
    print(countDown)
    if countDown == 4 {
        print("I'm bored. Let's go now!")
        break
    }
    countDown-=1
}

//exiting nested loops
outerLoop: for i in 1...10 {
    for j in 1...10 {
        let product = i*j
        print("\(i)*\(j) is \(product)")
        
        if product == 50 {
            print("It's a bullseye!")
            break outerLoop
        }
    }
}

//skipping items
for i in 1...10 {
    if i%2 == 1 {
        continue
    }
    print(i)
}

//infinite loops
var counter = 0
while true {
    print(" ")
    counter+=1
    if counter == 273 {
        break
    }
}

//writing functions
func printHelp() {
    let message="""
Welcome to MyApp!

Run this app inside a directory of images and MyApp will resize them all into thumbnails
"""
    print(message)
    
}
printHelp()

//accepting parameters
func square(number: Int) {
    print(number*number)
}
square(number: 8)

//returning values
func square2(number: Int) -> Int {
    return number*number
}
let result = square2(number: 8)
print(result)

//parameter labels
func sayHello(to name: String) {
    print("Hello, \(name)!")
}
sayHello(to: "Taylor")

//omitting parameter labels
func greet (_ person: String) {
    print("Hello, \(person)!")
}
greet("Taylor")

//default parameters
func greet2(_ person: String, nicely: Bool = true) {
    if nicely == true {
        print("Hello, \(person)!")
    } else {
        print("Oh no, it's \(person) again...")
    }
}
//test using default parameter
greet2("Taylor")
//test not using default parameter
greet2("Taylor", nicely: false)

//variadic functions
func square3(numbers: Int...) {
    for number in numbers {
        print("\(number) squared is \(number*number)")
    }
}
//prints squares of numbers 1-5
square3(numbers: 1,2,3,4,5)

//writing throwing functions
enum PasswordError: Error {
    case obvious
}
 
func checkPassword(_ password: String) throws -> Bool {
    if password == "password" {
        throw PasswordError.obvious
    }
    return true
}

//test with valid password
do {
    try checkPassword("fjbefkwed")
    print("That password is good!")
} catch {
    print("You can't use that password")
}
//test with invalid password
do {
    try checkPassword("password")
    print("That password is good!")
} catch {
    print("You can't use that password")
}

//inout parameters
func doubleInPlace(number: inout Int) {
    number*=2
}
var myNum=10
doubleInPlace(number: &myNum)

//basic closure
let driving = {
    print("I'm driving in my car")
}
driving()

//closure with parameters
let driving2 = { (place:String) in
    print("I'm going to \(place) in my car")
}
driving2("London")

//closure that returns value
let drivingWithReturn = { (place: String) -> String in
    return "I'm going to \(place) in my car"
}
//assigns message to return value and prints message
let message = drivingWithReturn("London")
print(message)

//closures as parameters
//accepts different traveling actions as parameters
func travel(action: () -> Void){
    print("I'm getting ready to go.")
    action()
    print("I arrived!")
}
//assigns driving() closure to parameter
travel(action: driving)

//trailing closure syntax
//last parameter of travel() func is closure --> can call with trailing closure syntax
travel() {
    print("I'm driving in my car")
}

//using closures that accept parameters as parameters
func travel2(action: (String) -> Void) {
    print("I'm getting ready to go.")
    action("London")
    print("I arrived!")
}
//required to accept string parameter
travel2 { (place: String) in
    print("I'm going to \(place) in my car")
}

//using closures that return values as parameters
func travel3(action: (String) -> String) {
    print("I'm getting ready to go.")
    let description = action("London")
    print(description)
    print("I arrived!")
}
//shorthand parameter names
//Swift knows this closure must accept and return string --> can remove
//only one line of code --> Swift knows it returns value
//can let Swift provide automatic parameter names ($+number counting from 0)
travel3 {
    "I'm going to \($0) in my car"
}

//closures with multiple parameters
//travel func that specifices place and speed
func travel4(action: (String, Int) -> String) {
    print("I'm getting ready to go.")
    let description=action("London", 60)
    print(description)
    print("I arrived!")
}
 //using trailing closure and shorthand parameter names
travel4 {
    "I'm going to \($0) at \($1) miles per hour."
}

//returning closures from functions
//one arrow for func's return value, one for closure's return value
//travel func that accepts no parameters, returns closure
func travel5() -> (String) -> Void {
    //counter for how many times closure is called
    var counter = 1
    return {
        print("\(counter). I'm going to \($0)")
        counter += 1
    }
}
//call travel to get closure, then call it as func
//technically allowed to return directly
let result2 = travel5()
//swift captures value of counter
result2("London")
result2("London")
result2("London")

//structs
struct Sport {
    var name: String
}
var tennis = Sport(name: "Tennis")
print(tennis.name)
tennis.name="Lawn tennis"
print(tennis.name)

//computed properties
struct Sport2 {
    var name: String
    var isOlympicSport: Bool
    
    var olympicStatus: String {
        if isOlympicSport {
            return "\(name) is an Olympic sport"
        } else {
            return "\(name) is not an Olympic sport"
        }
    }
}
//computes and prints Olympic Status of chessboxing
let chessBoxing = Sport2(name: "Chessboxing", isOlympicSport: false)
print(chessBoxing.olympicStatus)

//property observers
struct Progress {
    var task: String
    var amount: Int {
        //runs every time amount changes
        //can also use willSet to take action before property changes
        didSet {
            print("\(task) is now \(amount)% complete")
        }
    }
}

var progress = Progress(task: "Loading data", amount: 0)
progress.amount=30
progress.amount=80
progress.amount=100

//methods
//functions inside structs = methods, still use func keyword
struct City {
    var population: Int
    //method belongs to city -> can read population property
    func collectTaxes() -> Int {
        return population * 1000
    }
}
//call methods belonging to struct on instances of struct
let london = City(population: 9_000_000)
london.collectTaxes()

//mutating methods
struct Person {
    var name: String
    //mutating keyword allows you to change properties
    //only allowed to be called on Person instances that are variables
    mutating func makeAnonymous() {
        name="Anonymous"
    }
}

var person = Person(name: "Ed")
person.makeAnonymous()

//STRINGS AND ARRAYS ARE BOTH STRUCTS
//properties and methods of strings
let string = "Do or do not, there is no try."
print(string.count)//reads number of characters in string
print(string.hasPrefix("Do"))//returns true if string starts with specific letters
print(string.uppercased())//changes string to uppercase
print(string.sorted())//sorts letters of string into array

//properties and methods of arrays
var toys = ["Woody"]
print(toys.count)//reads number of items in array
toys.append("Buzz")//add new item to array
toys.firstIndex(of: "Buzz")//returns index of item in array
print(toys.sorted())//sorts items of array alphabetically
toys.remove(at: 0)//removes item at specified index

//initializers
struct User {
    var username: String
    //creates all new users as anonymous and prints message
    init() {
        username = "Anonymous"
        print("Creating a new user!")
    }
}
var user = User()
//changes username to twostraws
user.username = "twostraws"

//referring to the current instance
struct Person2 {
    var name: String
    //name refers to parameter, self.name refers to property
    init(name: String) {
        print("\(name) was born!")
        self.name=name
    }
}

//lazy properties
struct FamilyTree {
    init() {
        print("Creating family tree!")
    }
}
//use FamilyTree struct as property in Person struct
struct Person3 {
    var name: String
    lazy var familyTree = FamilyTree()//lazy keyword -> Swift will only create FamilyTree struct when first accessed
    
    init(name: String) {
        self.name = name
    }
}
var ed = Person3(name: "Ed")
ed.familyTree //must access property

//static properties and methods
struct Student {
    static var classSize = 0//stores number of students in class
    var name: String
    
    init(name: String) {
        self.name=name
        Student.classSize+=1//adds 1 to classSize when new student is created
    }
}

let ed2 = Student(name: "Ed")
let taylor2 = Student(name: "Taylor")
print(Student.classSize)//classSize property belongs to Student struct

//access control
struct Person4 {
    private var id: String//private keyword -> only methods inside struct can read property
    
    init(id: String) {
        self.id=id
    }
    //method inside struct that can read id property
    func identify() -> String {
        return "My social security number is \(id)"
    }
}

let ed3 = Person4(id: "12345")

//creating your own classes
class Dog { //final keyword makes class final -> no other class can inherit from it, other developers need to use it as written
    var name: String
    var breed: String
    
    init(name: String, breed: String) { //methods do not have memberwise initializer -> must create own
        self.name=name
        self.breed=breed
    }
}

let poppy=Dog(name: "Poppy", breed: "Poodle")

//class inheritance
class Poodle: Dog { //Poodle inherits properties and initializer from Dog
    init(name: String) { //breed always Poodle -> init only needs name property
        super.init(name: name, breed: "Poodle")//must call super.init() from child classes
    }
}

//overriding methods
class Dog2 {
    func makeNoise() {
        print("Woof!")
    }
}

class Poodle2: Dog2 {
    override func makeNoise() { //method overriding allows us to change implementation of makeNoise for Poodle2 class
        print("Yip!")
    }
}
let poppy2 = Poodle2()
poppy2.makeNoise()//prints Yip! rather than Woof!

//copying objects
class Singer {
    var name = "Taylor Swift"
}
var singer=Singer()
print(singer.name)//prints "Taylor Swift"
var singerCopy=singer
singerCopy.name = "Justin Bieber"
print(singer.name)//singer and singerCopy point to same object in memory -> prints "Justin Bieber"

//mutability
let taylor3 = Singer()
taylor3.name = "Ed Sheeran" //variable properties of classes can be changed without mutating keyword, make property a constant to prevent this
print(taylor3.name)

//deinitializers
class Person5 {
    var name = "John Doe"
    
    init() {
        print("\(name) is alive!")
    }
    
    func printGreeting() {
        print("Hello, I'm \(name)")
    }
    
    deinit { //called when the Person instance is being destroyed
        print("\(name) is no more!")
    }
}

for _ in 1...3 { //each time loop goes around new person is created and destroyed
    let person = Person5()
    person.printGreeting()
}

//protocols
protocol Identifiable { //requires comforming types to have an id string that can be read (get) or written (set)
    var id: String { get set }
}

struct User2: Identifiable { //can create struct that comforms to protocol
    var id: String
}

func displayID(thing: Identifiable) { //accepts any Identifiable object
    print("My ID is \(thing.id)") //prints id
}

//protocol inheritance
protocol Payable { //conforming types must implement calculateWages() method
    func calculateWages() -> Int
}

protocol NeedsTraining { //conforming types must implement study() method
    func study()
}

protocol HasVacation { //conforming types must implement takeVacation() method
    func takeVacation(days: Int)
}

protocol Employee: Payable, NeedsTraining, HasVacation {} //brings them all together in a single protocol

//extensions
extension Int { //adds squared() method to Int type
    func squared() -> Int {
        return self*self
    }
}

let num2 = 8
num2.squared()

//no stored properties in extensions, must used computed instead
extension Int {
    var isEven: Bool { //returns true if even
        return self % 2 == 0
    }
}

//protocol extensions
let pythons2 = ["Eric", "Graham", "John", "Michael", "Terry", "Terry"]
let beatles3 = Set(["John", "Paul", "George", "Ringo"])

extension Collection { //Swift's arrays and sets conform to protocol Collection
    func summarize() {
        print("There are \(count) of us:")
        
        for name in self {
            print(name)
        }
    }
}
//both Array and Set now have summarize() method
pythons2.summarize()
beatles3.summarize()

//protocol-oriented programming
protocol Identifiable2 {
    var id: String {get set}
    func identify()
}

extension Identifiable {
    func identify() { //default identify() method
        print("My ID is \(id)")
    }
}

struct User3: Identifiable {
    var id: String
}

let twostraws = User3(id: "twostraws")
twostraws.identify() //uses default identify() method from extension

//handling missing data
var age3: Int? = nil //to make a type optional, add ? after it
age3=38 //if we later learn age, we can use it

//unwrapping optionals
var name2: String? = nil
if let unwrapped = name2 { //if name holds a string, it will be put inside unwrapped and we can read its count properly
    print("\(unwrapped.count) letters")
} else { // if name is empty, else condition will run
    print("Missing name.")
}

//unwrapping with guard
func greet(_ name: String?) { //accepts optional string as parameter, tries to unwrap it, if nothing inside prints message and exits
    guard let unwrapped = name else {
        print("You didn't provide a name!")
        return
    }

    print("Hello, \(unwrapped)!") //optionals unwrapped using guard let stay after guard finishes
}

//force unwrapping
let str5 = "5"
let num3 = Int(str) //makes num3 an optional Int
let num4 = Int(str)! //! force unwraps the result, makes num4 regular Int rather than an Int?, if str could not be converted to Int then code will crash
//FORCE UNWRAP ONLY WHEN SURE IT'S SAFE

//implicitly unwrapped optionals
//don't need to be unwrapped to use, don't need if let/guard let, if they have no value and you try to use them your code crashes
let age4: Int! = nil //created by adding ! after type name

//nil coalescing
func username(for id: Int) -> String? {
    if id == 1 {
        return "Taylor Swift"
    } else {
        return nil
    }
}

let user4 = username(for: 15) ?? "Anonymous" //checks result from username() function, if it is a string then it is unwrapped and placed into user, if it has nil then default value "Anonymous" used instead

//optional chaining
let names = ["John", "Paul", "George", "Ringo"]
let beatle = names.first?.uppercased() //? is optional chaining - if first returns nil Swift will set beatle to nil immediately

//failable initializers
struct Person6 { //must be created using 9-letter ID string, if anything else is used returns nil
    var id: String

    init?(id: String) {
        if id.count == 9 {
            self.id = id
        } else {
            return nil
        }
    }
}

//typecasting
class Animal { }
class Fish: Animal { }
class Dog3: Animal {
    func makeNoise() {
        print("Woof!")
    }
}
let pets = [Fish(), Dog3(), Fish(), Dog3()] //Swift sees both Fish and Dog inherit from Animal class, uses type ingerence to make pets array of Animal

//typecast: Swift checks if each pet is a Dog, if it is we can call makeNoise()
for pet in pets {
    if let dog = pet as? Dog3 { //as? keyword returns optional, nil if the typecast failed, converted type otherwise
        dog.makeNoise()
    }
}

